'use strict';

angular.module('maktabAppApp')
  .controller('DashboardCtrl', function ($scope, $location, $http, $timeout, Auth) {

console.log("logged in");
  });
